<!DOCTYPE html>
<html>
<head>
	<title>Barangay Health Center</title>
</head>
<style type="text/css">
	*{
		margin: 0px;
		padding: 0px;
	}
	body{
		background: #FFBB98;
	}
	header{
		padding: 30px;
		background: #FBE0C3;
		text-align: center;
		font-size: 25px;
		font-family: sans-serif;
	}
	nav{
		text-align: center;
	}
	nav :hover{
		background-color: #FBE0C3;
	}
	.nav
	{
		text-decoration: none;
		padding: 20px;
		color: black;
		font-size: 15px;
		font-family: sans-serif;
	}
	img{
		width: 980px;
		height: 450px;
		margin-left:70px; 

	}
	

.img-img {
  /* The image used */
  background-image: url("img.jpg");
  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
 
  
}

/* Add styles to the form container */


	.header{
		width: 30%;
		margin: 50px auto 0px;
		color: white;
		background: #5F9EA0;
		text-align: center;
		border: 1px solid:#B0C4DE;
		border-bottom: none;
		border-radius: 10px 10px 0px 0px;
		padding: 20px;
	}
	form{
		width: 30%;
		margin: 0px auto;
		padding: 20px;
	
		margin-right: 130px;
		border-radius: 0px 0px 10px 10px;
	}
	.input-group{
		margin: 10px 0px 10px 0px;
	}
	.input-group label{
		display: block;
		text-align: left;
		margin: 3px;
	}
	.input-group input{
		height: 30px;
		width: 93%;
		padding: 5px 10px;
		font-size: 16px;
		border-radius: 5px;
		border: 1px solid gray;
	}
	.btn{
		padding: 10px;
		font-size: 15px;
		color: white;
		background: #5F9EA0;
		border: none;
		border-radius: 5px;
	}
	p{
color: black;
		font-size: 20px;
		font-family: sans-serif;

	}
	h1{
		color: black;
		font-size: 20px;
		font-family: sans-serif;
		text-align: center;
	}
	h2{
		color: black;
		font-size: 25px;
		font-family: 'Brush Script MT', cursive;
		text-align: center;
	}
	
	
	.row img{
    
       margin-left: 200px;
  padding:5px;
    width: 350px;
    height: 150px


}
	footer{
		margin-top: 30px;
		padding: 20px;
		background: #FBE0C3;
		text-align: center;
		font-size: 20px;
		font-family: sans-serif;
	}
</style>
<body>
<header><strong>Calepaan Health Center</strong></header>
<br>
<br>
<nav>
	<a href="health.php" class="nav">Home</a>
	<a href="check.php" class="nav">Check Up</a>
	<a href="about.php" class="nav">About</a>
</nav>
<h1> 
<br>
<div class=" img-img">
	<form method="POST" action="reg.php" class="container">
	<h1>Register</h1>
		<div class="input-group">
		<label>Username</label>
		<input type="text" name="username">
		</div>
		<div class="input-group">
		<label>Email</label>
		<input type="text" name="email">
		</div>
		<div class="input-group">
		<label>Password</label>
		<input type="password" name="pass">
		</div>
		<div class="input-group">
		<label>Confirm Password</label>
		<input type="password" name="cpass">
		</div>
		<div class="input-group">
			<button type="submit" name="register" class="btn">Register</button>
		</div>

		<p>
			Already a member? <a href="login.php">Sign in</a>
		</p>
	</form>
	</div>
<br>
	<p>“A resource for everyday life, not the objective of living. Health is a positive concept emphasizing social and personal resources, as well as physical capacities.”
    This means that health is a resource to support an individual’s function in wider society, rather than an end in itself. A healthful lifestyle provides the means to lead a full life with meaning and purpose.
    Your health is at the center of your life. Every part of your life relies on you having good health.</p>
    <br>
	<h2>Maintaining good health should be the primary focus of everyone. 
	-Sangram Singh</h2>
<br>
<div class="row">
<img src="hw.jpg"  >
<img src="pic7.jpg"  >

</div>
	<footer>Copyright &copy; 2020</footer>
</body>
</html>