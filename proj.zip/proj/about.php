<!DOCTYPE html>
<html>
<head>
	<title>Barangay Health Center</title>
</head>
<style type="text/css">
	*{
		margin: 0px;
		padding: 0px;
	}
	body{
		background: #FFBB98;
	}
	header{
		padding: 30px;
		background: #FBE0C3;
		text-align: center;
		font-size: 25px;
		font-family: sans-serif;
	}
	nav{
		text-align: center;
	}
	nav :hover{
		background-color: #FBE0C3;
	}
	.nav
	{
		text-decoration: none;
		padding: 20px;
		color: black;
		font-size: 15px;
		font-family: sans-serif;
	}
	img{
		width: 800px;
		height: 600px;
		margin-left:240px
	}
	p{
		text-align: center;
		font-size: 20px;
		font-family: sans-serif;
	}
	
.row img{
    
       margin-left: 100px;
  padding:5px;
    width: 200px;
    height: 150px


}

	footer{
		margin-top: 50px;
		padding: 20px;
		background: #FBE0C3;
		text-align: center;
		font-size: 20px;
		font-family: sans-serif;
	}
</style>
<body>
<header><strong>Calepaan Health Center</strong></header>
<br>
<br>
<nav>
	<a href="health.php" class="nav">Home</a>
	<a href="check.php" class="nav">Check Up</a>
	<a href="about.php" class="nav">About</a>
</nav>
<br>
<img src="bh.jpeg">


<br>
<br>
<br>
<p>
What is Barangay Health Center?
<br>
Brgy.Health Care Management System is  a community-based and patient-directed organization.<br>
Its goal is to provide first aid, maternal and child health care,diagnosis of social diseases and other basic health services to all the members of the community it is serving.Barangay Health Center is Located @ Calepaan,Asingan,Pangasinan. Where check-ups are free for everyone.Every
Monday, Wednesday and Friday. Also midwife, nurse and Barangay Health Workers are very approachable. </p>

<br>
<br>
<br>
<div class="row">
<img src="p1.jpg"  >
<img src="p3.jpg"  >
<img src="p4.jpg"  >
<img src="p5.jpg"  >
</div>

	<footer>Copyright &copy; 2020</footer>
</body>
</html>