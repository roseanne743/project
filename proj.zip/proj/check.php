<!DOCTYPE html>
<html>
<head>
	<title>Barangay Health Center</title>
</head>
<style type="text/css">
	body{
		background: #FFBB98;
	}
	header{
		padding: 30px;
		background: #FBE0C3;
		text-align: center;
		font-size: 25px;
		font-family: sans-serif;
	}
	nav{
		text-align: center;
	}
	nav :hover{
		background-color: #FBE0C3;
	}
	.nav
	{
		text-decoration: none;
		padding: 20px;
		color: black;
		font-size: 15px;
		font-family: sans-serif;
	}
	.search{
		margin: 10px 0px 10px 0px;
	}
	.search label{
		padding-top: 50px;
		display: block;
		text-align: center;
		margin: 3px;
	}
	.search input{
		margin-left: 450px;
		height: 30px;
		width: 43%;
		padding: 5px 10px;
		font-size: 16px;
		border-radius: 5px;
		border: 1px solid gray;
	}
	.btn{
		margin-left: 660px;
		padding: 10px;
		width: 13%;
		font-size: 15px;
		color: white;
		background-color: #7D8E95;
		border: none;
		border-radius: 5px;
	}
	table, th, td{
		border: 2px solid black;
		border-collapse: collapse;
	}
	th td{
		padding: 5px;
		text-align: center;
	}
	.insert{
		margin-left: 660px;
		padding: 10px;
		width: 13%;
		font-size: 15px;
		color: white;
		background-color: #7D8E95;
		border: none;
		border-radius: 5px;
		}
	footer{
		margin-top: 450px;
		padding: 20px;
		background: #FBE0C3;
		text-align: center;
		font-size: 20px;
		font-family: sans-serif;
	}
</style>
<body>
<header><strong>Calepaan Health Center</strong></header>
<br>
<br>
<nav>
	<a href="health.php" class="nav">Home</a>
	<a href="check.php" class="nav">Check Up</a>
	<a href="about.php" class="nav">About</a>
</nav>
<br>
<form action="" method="POST">
	<div class="search">
		<label>Search Folder Number</label><input type="text" name="fold_no" placeholder="Search Folder Number">
		<br>
		<input type="submit" name="btnsearch" value="search" class="btn">
	</div>
		<br>
	</form>
		<?php
			$connect = mysqli_connect("localhost","root","");
			$db= mysqli_select_db($connect,'dbCheck-up');

		if (isset($_POST['btnsearch'])) {
		$fold_no = $_POST['fold_no'];
		$query = "SELECT * FROM tblCheckUP where fold_no='$fold_no' ";
		$query_run = mysqli_query($connect,$query);

		while ($row = mysqli_fetch_array($query_run)) 
		{
			?>
			<table style="width: 100%">
		<tr>
		<th>Date</th>
		<th>Folder Number</th>
		<th>Fullname</th>
		<th>Age</th>
		<th>CC</th>
		<th>Rx</th>
	</tr>
	<tr>
		<td><input type="text" name="datee" value="<?php echo $row['datee'] ?>"></td>
		<td><input type="text" name="fold_no" value="<?php echo $row['fold_no'] ?>"></td>
		<td><input type="text" name="name" value="<?php echo $row['name'] ?>"></td>
		<td><input type="text" name="age" value="<?php echo $row['age'] ?>"></td>
		<td><input type="text" name="pres_cc" value="<?php echo $row['pres_cc'] ?>"></td>
		<td><input type="text" name="rx" value="<?php echo $row['rx'] ?>"></td>
	</tr>
			</table>
				<form action="insert.php" method="POST">
						<input type="submit" name="btnedit" value="Edit" class="insert">
			</form>
		<?php	
		}
	}
?>
		<footer>Copyright &copy; 2020</footer>
	</body>
</html>