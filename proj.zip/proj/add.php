<!DOCTYPE html>
<html>
<head>
	<title>Barangay Health Center</title>
</head>
<style type="text/css">
	body{
		background: #FFBB98;
	}
	header{
		padding: 30px;
		background: #FBE0C3;
		text-align: center;
		font-size: 25px;
		font-family: sans-serif;
	}
	nav{
		text-align: center;
	}
	nav :hover{
		background-color: #FBE0C3;
	}
	.nav
	{
		text-decoration: none;
		padding: 20px;
		color: black;
		font-size: 15px;
		font-family: sans-serif;
	}
	.search{
		margin: 10px 0px 10px 0px;
	}
	.search label{
		padding-top: 50px;
		display: block;
		text-align: center;
		margin: 3px;
	}
	.search input{
		margin-left: 450px;
		height: 30px;
		width: 43%;
		padding: 5px 10px;
		font-size: 16px;
		border-radius: 5px;
		border: 1px solid gray;
	}
	.btn{
		margin-left: 660px;
		padding: 10px;
		width: 13%;
		font-size: 15px;
		color: white;
		background-color: #7D8E95;
		border: none;
		border-radius: 5px;
	}
	footer{
		margin-top: 450px;
		padding: 20px;
		background: #FBE0C3;
		text-align: center;
		font-size: 20px;
		font-family: sans-serif;
	}
</style>
<body>
<header><strong>Calepaan Health Center</strong></header>
<br>
<br>
<nav>
	<a href="health.php" class="nav">Home</a>
	<a href="check.php" class="nav">Check Up</a>
	<a href="about.php" class="nav">About</a>
</nav>
<br>
	<h1>Data's</h1>
	<form action="" method="POST">
		<label>Date: </label><input type="text" name="date" ><br>
				<label>Folder Number: </label><input type="text" name="fold_no"><br>
				<label>Fullname: </label><input type="text" name="name"><br>
				<label>Age: </label><input type="text" name="age"><br>
				<label>Prescription: </label><input type="text" name="pres_cc"><br>
				<label>Rx: </label><input type="text" name="rx"><br>

				<input type="submit" name="btnadd" value="Add">
<?php
	
	$connect= mysqli_connect("localhost","root","");
	$db = mysqli_select_db($connect,'dbCheck-up');



?>
	</form>
<footer>Copyright &copy; 2020</footer>
	</body>
</html>